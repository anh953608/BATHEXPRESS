package bath.group3.model;

public class Comment {

	public Comment() {
		// TODO Auto-generated constructor stub
	}
	
}
