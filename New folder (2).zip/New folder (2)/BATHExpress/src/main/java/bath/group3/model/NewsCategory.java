	package bath.group3.model;

public class NewsCategory {

	public NewsCategory() {
		// TODO Auto-generated constructor stub
	}

}
