package bath.group3.model;

public class FeedBack {

	public FeedBack() {
		// TODO Auto-generated constructor stub
	}

}
