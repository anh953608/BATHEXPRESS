package bath.group3.dao;

public class NewsDAO {

	public NewsDAO() {
		// TODO Auto-generated constructor stub
	}

}
