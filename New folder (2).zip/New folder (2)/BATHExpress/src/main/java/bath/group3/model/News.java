package bath.group3.model;

public class News {

	public News() {
		// TODO Auto-generated constructor stub
	}

}
