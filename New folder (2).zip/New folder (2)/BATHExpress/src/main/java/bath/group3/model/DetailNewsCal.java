package bath.group3.model;

public class DetailNewsCal {

	public DetailNewsCal() {
		// TODO Auto-generated constructor stub
	}

}
