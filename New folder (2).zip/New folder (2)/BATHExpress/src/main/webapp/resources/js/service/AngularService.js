'use strict';

angular.module('myApp').factory('HelloAngularService', ['$http', function($http){
	var URL = '/BATHExpress/getStringHello/';
	var factory = {};
	factory.fetchHello = (callbackData,error) => { 
		$http.get(URL)
		.then(function(response){
				callbackData(response.data);
			}).catch(function(error){console.log('fetch data error!')});
	}
	return factory;
}]);