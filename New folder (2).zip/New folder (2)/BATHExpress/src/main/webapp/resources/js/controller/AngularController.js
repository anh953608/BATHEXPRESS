'use strict';
angular.module('myApp').controller('HelloAngularController', ['$scope', 'HelloAngularService', function($scope, HelloAngularService) {
	fetchHellos();
	$scope.hello = [];
	function fetchHellos(){
		HelloAngularService.fetchHello(function(response){
			$scope.hello = response;
			console.log(response);
		});
		
	}
}]);